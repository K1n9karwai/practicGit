package inheritance;

import java.util.Scanner;

public class ExamMain {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		int people;
		
		System.out.print("�ο��� �Է� : ");
		people = Integer.parseInt(scan.next());
		Exam[] ex = new Exam[people];
		
		for(int i=0; i<people; i++) {
			ex[i] = new Exam();
			ex[i].compare();
		}
		
		System.out.println("�̸�\t1 2 3 4 5\t����");
		for(int i=0; i<people; i++) {
			System.out.print(ex[i].getName()+"\t");
			ex[i].getOx();
			System.out.println("\t"+ex[i].getScore());
		}
		
	}
}
