package inheritance;

public class EmployeeDTO {

	private String name;
	private String position;
	private int basepay;
	private int benefit;
	private double taxRate;
	private int salary;
	
	public EmployeeDTO(String name, String position, int basepay, int benefit) {
		this.name = name;
		this.position = position;
		this.basepay = basepay;
		this.benefit = benefit;
		
		int total = basepay + benefit;
		
		if(total<2000000) {
			taxRate = 0.01;
			salary = (int)(total - total*taxRate);
		} else if(total<4000000) {
			taxRate = 0.02;
			salary = (int)(total - total*taxRate);
		} else {
			taxRate = 0.03;
			salary = (int)(total - total*taxRate);
		}
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPosition() {
		return position;
	}

	public void setPosition(String position) {
		this.position = position;
	}

	public int getBasepay() {
		return basepay;
	}

	public void setBasepay(int basepay) {
		this.basepay = basepay;
	}

	public int getBenefit() {
		return benefit;
	}

	public void setBenefit(int benefit) {
		this.benefit = benefit;
	}

	public double getTaxRate() {
		return taxRate;
	}

	public void setTaxRate(double taxRate) {
		this.taxRate = taxRate;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}
	
}
