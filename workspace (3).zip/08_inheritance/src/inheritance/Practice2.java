package inheritance;

public class Practice2 {

	public static void main(String[] args) {
		
		SalaryManager sm = new SalaryManager();
		
	}
}
