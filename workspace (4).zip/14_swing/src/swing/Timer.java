package swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

public class Timer extends JFrame implements ActionListener, Runnable {
	
	private JButton startBtn = new JButton("����");
	private JButton stopBtn = new JButton("����");
	private JLabel jl = new JLabel();
	
	public Timer() {
		
		super("Timer");
		
		Container con = getContentPane();
		con.setLayout(new BorderLayout());
		con.add("North", new JLabel("20�� Ÿ�̸�"));
		//���� ����
		con.add("Center", jl);
		//jl.setText();
		jl.setHorizontalAlignment(JLabel.CENTER);
		jl.setFont(new Font("Serif", Font.BOLD, 50));
		jl.setForeground(Color.BLUE);
		
		JPanel jp = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		jp.add(startBtn);
		jp.add(stopBtn);
		
		startBtn.addActionListener(this);
		stopBtn.addActionListener(this);
		
		con.add("South", jp);
		setSize(300,300);
		setVisible(true);
		
	}
	
	private boolean bb =true;
	

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==startBtn) {
			bb = true;
			new Thread(this).start();
			startBtn.setEnabled(false);
			stopBtn.setEnabled(true);
		} else if (e.getSource()==stopBtn) {
			bb = false;
			startBtn.setEnabled(true);
			stopBtn.setEnabled(false);
		}
		
	}
	
//	@Override
//	public void paint(Graphics g) {
//		g.drawString(i+"", 150, 150);
//		repaint();
//	}

	@Override
	public void run() {
		
		for(int i=1; i<=20; i++) {
			if(!bb) break;
			try {
				Thread.sleep(1000);
			} catch (InterruptedException ee) {}
			
			jl.setText(i+"");
		}
		startBtn.setEnabled(true);
		stopBtn.setEnabled(false);
		
	}
	
	public static void main(String[] args) {
		new Timer();
	}
	
}
