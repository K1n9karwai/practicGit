package swing;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.DefaultListModel;

//JRadiobutton�� �⺻�� �簢���� üũ
//���� ���� �����ϸ� �ڵ����� �簢����  ����

//Canvas�� �⺻ ���� ����������� �Ѵ�.

//x1T, y1T, x2T, y2T �̰��� ��ǥ�� �Է��ϰ� �׸��� ��ư�� ������ ���ϴ� �������� Canvas�� �׷�����
//������ JComboBox���� ����
//�ձ� �簢���� ���η����� ������ 50�� �ش�.
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

public class MsPaint extends JFrame implements ActionListener {
	
	private JLabel x1L, y1L, x2L, y2L, z1L, z2L;
	private JTextField x1T, y1T, x2T, y2T, z1T, z2T;
	private JCheckBox fill;
	private JRadioButton line, circle, rect, roundRect;
	private JComboBox combo;
	private	JButton draw;
	private DrCanvas can;
	private int sw;
//	private Container con = getContentPane();
	
	private String num1, num2, num3, num4;
	
	private ButtonGroup grp = new ButtonGroup();
	private JRadioButton[] rb = new JRadioButton[4];
	
	public MsPaint() {
		super("MsPaint");
		setTitle("�̴� �׸���");
		
		Container con = getContentPane();
		con.setLayout(new BorderLayout());
		
		JPanel jp = new JPanel();
		x1L = new JLabel("x1L"); y1L = new JLabel("y1L");
		x2L = new JLabel("x2L"); y2L = new JLabel("y2L");
		z1L = new JLabel("z1L"); z2L = new JLabel("z2L");

		x1T = new JTextField(3); y1T = new JTextField(3);
		x2T = new JTextField(3); y2T = new JTextField(3);
		z1T = new JTextField(3); z2T = new JTextField(3);
		fill = new JCheckBox("ä���");
		
		jp.add(x1L); jp.add(x1T); jp.add(y1L); jp.add(y1T);
		jp.add(x2L); jp.add(x2T); jp.add(y2L); jp.add(y2T);
		jp.add(z1L); jp.add(z1T); jp.add(z2L); jp.add(z2T);
		jp.add(fill);
		
		con.add("North", jp);
		
//		JPanel jp3 = new JPanel();
//		jp3.setBackground(new Color(125,200,210));
//		con.add("Center", jp3);
//		
		
		JPanel jp2 = new JPanel();
		
		
		
//		line = new JRadioButton("��"); circle = new JRadioButton("��");
//		rect = new JRadioButton("�簢��"); roundRect = new JRadioButton("�ձ� �簢��");
//		JRadioButton[] listData = {line, circle, rect, roundRect};
//		JList<JRadioButton> list = new JList<JRadioButton>(listData);
////		list.setSelectedIndex(1);
		
		
		
		line = new JRadioButton("��"); circle = new JRadioButton("��");
		rect = new JRadioButton("�簢��"); roundRect = new JRadioButton("�ձ� �簢��");
		
		combo = new JComboBox(); draw = new JButton("�׸���");
		combo.addItem("����"); combo.addItem("�ʷ�");
		combo.addItem("�Ķ�"); combo.addItem("����");
		combo.addItem("�ϴ�");
	
		//ArrayList<JRadioButton> list = new ArrayList<JRadioButton>();

		
		//list.add(line); list.add(circle); list.add(rect); list.add(roundRect);
		
		//jp2.add(list.get(0)); jp2.add(list.get(1)); jp2.add(list.get(2)); jp2.add(list.get(3));
 		
		
		rb[0] = new JRadioButton("��");
		rb[1] = new JRadioButton("��");
		rb[2] = new JRadioButton("�簢��");
		rb[3] = new JRadioButton("�ձ� �簢��");
		
		for(JRadioButton c : rb) {
			grp.add(c);
			jp2.add(c);
		}
		
		rb[2].setSelected(true);
		
		
		
		jp2.add(combo); jp2.add(draw);
		
		con.add("South", jp2);
		
		
		
		
		draw.addActionListener(this);
		rb[0].addActionListener(this);
		rb[1].addActionListener(this);
		rb[2].addActionListener(this);
		rb[3].addActionListener(this);
		x1T.addActionListener(this);
		y1T.addActionListener(this);
		x2T.addActionListener(this);
		y2T.addActionListener(this);
		
		
		
		setSize(550,400);
		setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("�׼� ��Դ�");
		if(e.getSource()==rb[0]) {
			sw=1;
			System.out.println("��");
		} else if(e.getSource()==rb[1]) {
			sw=2;
			System.out.println("��");
		} else if(e.getSource()==rb[2]) {
			sw=3;
			System.out.println("�簢");
		} else if(e.getSource()==rb[3]) {
			sw=4;
			System.out.println("�ձٻ簢");
		}
		
		if(e.getSource()==draw) {
			System.out.println("draw��Դ�");
			num1 = x1T.getText();
			num2 = y1T.getText();
			num3 = x2T.getText();
			num4 = y2T.getText();
			
			can = new DrCanvas(num1, num2, num3, num4, sw);
			con.add("Center", can);
		}
		
	}
	
	public static void main(String[] args) {
		
		new MsPaint();
		
	}
}
