package nested;

public abstract class AbstractExam {
	public void cc() {}//�� body
	public void dd() {}
}
