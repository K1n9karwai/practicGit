package nested;

public abstract class AbstractTest {
	String name;
	
	public abstract void setName(String name);
	
	public String getName() {
		return name;
	}
}
