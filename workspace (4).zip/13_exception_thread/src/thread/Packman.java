package thread;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Paint;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Packman extends Frame implements KeyListener, Runnable {

	private Image img;
	private Image food;
	private int sel=2;
	private int x=225, y=225;
	private int mx, my;
	private int[] x2 = new int[5]; 
	private int[] y2 = new int[5];
	private int count;
	public Packman() {

		img = Toolkit.getDefaultToolkit().getImage("packman.jpg");
		food = Toolkit.getDefaultToolkit().getImage("food.jpg");
		
		//setBackground(new Color(45, 120, 170));
		setBounds(800, 300, 500, 500);
		setResizable(false);
		setVisible(true);

		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		
		for(int i=0; i<5; i++) {
			x2[i] = (int)(Math.random()*440)+30;
			y2[i] = (int)(Math.random()*420)+50;
		}

		addKeyListener(this);
		//������ ����
		Thread t = new Thread(this);
		t.start();
		
	}

	public void paint(Graphics g) {
		g.drawImage(img, x, y, x+50, y+50, // ȭ�� ��ġ
				sel * 50, 0, sel * 50 + 50, 50, // ������ �̹��� ���� ��ġ
				this);
		
		for(int i=0; i<5; i++) {
			g.drawImage(food, x2[i], y2[i], x2[i]+20, y2[i]+20,
					0, 0, 20, 20, this);
		}
		
		for(int i=0; i<5; i++) {
			if(((x+25)>=x2[i]&&(x+25)<=x2[i]+20) && ((y+25)>=y2[i]&&(y+25)<=y2[i]+20)) {
				System.out.println("��Ҵ�");
				
				x2[i] = -1;
				y2[i] = -1;
			}
			
		}
	
	}
	
	@Override
	public void run() {
		while(true) {
			
			if(sel%2==0) sel++;
			else sel--;
			
			x+=mx;
			y+=my;
			if(x>500) x=0;
			else if(x<0) x=500;
			else if(y>500) y=0;
			else if(y<0) y=500;
			
			
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			repaint();
		}
 	}

	@Override
	public void keyPressed(KeyEvent e) {
		if (e.getKeyCode() == KeyEvent.VK_ESCAPE)
			System.exit(0);
		else if (e.getKeyCode() == KeyEvent.VK_LEFT) {
			sel = 0;
			mx=-10; my=0;
		}
		else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
			sel = 2;
			mx=10; my=0;
		}
		else if (e.getKeyCode() == KeyEvent.VK_UP) {
			sel = 4;
			mx=0; my=-10;
		}
		else if (e.getKeyCode() == KeyEvent.VK_DOWN) {
			sel = 6;
			mx=0; my=10;
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0) {

	}

	@Override
	public void keyTyped(KeyEvent arg0) {

	}

	public static void main(String[] args) {

		new Packman();

	}
}
